const { getData, getRandomGame } = require("./api-utils")
const endpoints = require("./config")




module.exports = {
    endpoints,
    getData,
    getRandomGame,
}